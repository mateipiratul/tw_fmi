document.addEventListener("DOMContentLoaded", () => {
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const tableContainer = document.getElementById("vigenere-container");

    // header generations
    tableContainer.innerHTML += '<div id="vigenere-item"></div>'; // top-left corner
    for (let i = 0; i < alphabet.length; i++) {
        tableContainer.innerHTML += `<div id="vigenere-item">${alphabet[i]}</div>`;
    }

    for (let i = 0; i < alphabet.length; i++) {
        tableContainer.innerHTML += `<div id="vigenere-item">${alphabet[i]}</div>`; // first column
        for (let j = 0; j < alphabet.length; j++) {
            const shiftedLetter = alphabet[(j + i) % alphabet.length];
            tableContainer.innerHTML += `<div>${shiftedLetter}</div>`;
        }
    }
});
